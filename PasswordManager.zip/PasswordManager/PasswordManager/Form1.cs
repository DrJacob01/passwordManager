﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PasswordManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MakePasswordSecret();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblHelloWorld.Text = "Hello World!";
            // Check if the entered username and password match
            if (UsernameBox.Text == "Jacob" && PasswordBox.Text == "Admin")
            {
                // Display a message indicating successful login
                MessageBox.Show("Login successful!", "Success");

                this.Hide();
                Form2 form2 = new Form2();
                form2.Show();
            }
            else
            {
                // Display a message indicating incorrect login information
                MessageBox.Show("Incorrect username or password. Please try again.", "Error");

                // Clear the username field
                UsernameBox.Clear();
                // Clear the password field
                PasswordBox.Clear();
            }
        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void MakePasswordSecret()
        {
            // Set to no text.
            PasswordBox.Text = "";
            // The password character is an asterisk.
            PasswordBox.PasswordChar = '*';
            // The control will allow no more than 14 characters.
            PasswordBox.MaxLength = 14;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void PasswordText_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
