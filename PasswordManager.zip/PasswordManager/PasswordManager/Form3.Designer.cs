﻿
namespace PasswordManager
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ApplicationNameText = new System.Windows.Forms.Label();
            this.UsernameEmailText = new System.Windows.Forms.Label();
            this.PasswordText = new System.Windows.Forms.Label();
            this.UsernameEmailTextBox = new System.Windows.Forms.TextBox();
            this.ApplicationNameTextBox = new System.Windows.Forms.TextBox();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.passwordManagerDataSet = new PasswordManager.PasswordManagerDataSet();
            this.passwordManagerDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter = new PasswordManager.PasswordManagerDataSetTableAdapters.TableTableAdapter();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.applicationNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaveButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordManagerDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordManagerDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // ApplicationNameText
            // 
            this.ApplicationNameText.AutoSize = true;
            this.ApplicationNameText.ForeColor = System.Drawing.Color.White;
            this.ApplicationNameText.Location = new System.Drawing.Point(63, 82);
            this.ApplicationNameText.Name = "ApplicationNameText";
            this.ApplicationNameText.Size = new System.Drawing.Size(90, 13);
            this.ApplicationNameText.TabIndex = 0;
            this.ApplicationNameText.Text = "Application Name";
            this.ApplicationNameText.UseWaitCursor = true;
            // 
            // UsernameEmailText
            // 
            this.UsernameEmailText.AutoSize = true;
            this.UsernameEmailText.ForeColor = System.Drawing.Color.White;
            this.UsernameEmailText.Location = new System.Drawing.Point(63, 112);
            this.UsernameEmailText.Name = "UsernameEmailText";
            this.UsernameEmailText.Size = new System.Drawing.Size(91, 13);
            this.UsernameEmailText.TabIndex = 1;
            this.UsernameEmailText.Text = "Username / Email";
            this.UsernameEmailText.UseWaitCursor = true;
            // 
            // PasswordText
            // 
            this.PasswordText.AutoSize = true;
            this.PasswordText.ForeColor = System.Drawing.Color.White;
            this.PasswordText.Location = new System.Drawing.Point(63, 146);
            this.PasswordText.Name = "PasswordText";
            this.PasswordText.Size = new System.Drawing.Size(53, 13);
            this.PasswordText.TabIndex = 2;
            this.PasswordText.Text = "Password";
            this.PasswordText.UseWaitCursor = true;
            // 
            // UsernameEmailTextBox
            // 
            this.UsernameEmailTextBox.Location = new System.Drawing.Point(159, 112);
            this.UsernameEmailTextBox.Name = "UsernameEmailTextBox";
            this.UsernameEmailTextBox.Size = new System.Drawing.Size(211, 20);
            this.UsernameEmailTextBox.TabIndex = 3;
            // 
            // ApplicationNameTextBox
            // 
            this.ApplicationNameTextBox.Location = new System.Drawing.Point(159, 79);
            this.ApplicationNameTextBox.Name = "ApplicationNameTextBox";
            this.ApplicationNameTextBox.Size = new System.Drawing.Size(211, 20);
            this.ApplicationNameTextBox.TabIndex = 3;
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Location = new System.Drawing.Point(159, 143);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(211, 20);
            this.PasswordTextBox.TabIndex = 4;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.applicationNameDataGridViewTextBoxColumn,
            this.usernameDataGridViewTextBoxColumn,
            this.passwordDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tableBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(389, 79);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(443, 345);
            this.dataGridView1.TabIndex = 5;
            // 
            // passwordManagerDataSet
            // 
            this.passwordManagerDataSet.DataSetName = "PasswordManagerDataSet";
            this.passwordManagerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // passwordManagerDataSetBindingSource
            // 
            this.passwordManagerDataSetBindingSource.DataSource = this.passwordManagerDataSet;
            this.passwordManagerDataSetBindingSource.Position = 0;
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "Table";
            this.tableBindingSource.DataSource = this.passwordManagerDataSet;
            // 
            // tableTableAdapter
            // 
            this.tableTableAdapter.ClearBeforeFill = true;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // applicationNameDataGridViewTextBoxColumn
            // 
            this.applicationNameDataGridViewTextBoxColumn.DataPropertyName = "Application Name";
            this.applicationNameDataGridViewTextBoxColumn.HeaderText = "Application Name";
            this.applicationNameDataGridViewTextBoxColumn.Name = "applicationNameDataGridViewTextBoxColumn";
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "Username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "Username";
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "Password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "Password";
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(159, 195);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(211, 48);
            this.SaveButton.TabIndex = 6;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(868, 467);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.PasswordTextBox);
            this.Controls.Add(this.ApplicationNameTextBox);
            this.Controls.Add(this.UsernameEmailTextBox);
            this.Controls.Add(this.PasswordText);
            this.Controls.Add(this.UsernameEmailText);
            this.Controls.Add(this.ApplicationNameText);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordManagerDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordManagerDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ApplicationNameText;
        private System.Windows.Forms.Label UsernameEmailText;
        private System.Windows.Forms.Label PasswordText;
        private System.Windows.Forms.TextBox UsernameEmailTextBox;
        private System.Windows.Forms.TextBox ApplicationNameTextBox;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.DataGridView dataGridView1;
        private PasswordManagerDataSet passwordManagerDataSet;
        private System.Windows.Forms.BindingSource passwordManagerDataSetBindingSource;
        private System.Windows.Forms.BindingSource tableBindingSource;
        private PasswordManagerDataSetTableAdapters.TableTableAdapter tableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn applicationNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button SaveButton;
    }
}