﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PasswordManager
{
    public partial class Form3 : Form
    {

        // Global - this is connecting the database to the displaying password. 
        PasswordManagerDataSetTableAdapters.TableTableAdapter passAdapt = new PasswordManagerDataSetTableAdapters.TableTableAdapter();


        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'passwordManagerDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.passwordManagerDataSet.Table);
       

        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            passAdapt.AddPassword(ApplicationNameTextBox.Text, UsernameEmailTextBox.Text, PasswordTextBox.Text);



            //LabelSuccess.Show();
            //clearing all fields from the cells
            ApplicationNameTextBox.Clear();
            UsernameEmailTextBox.Clear();
            PasswordTextBox.Clear();
            ApplicationNameTextBox.Focus();



            //updates grid
            gridUpdate();


        }

        private void gridUpdate()
        {


        }
    }
}
