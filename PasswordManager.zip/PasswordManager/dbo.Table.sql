﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Application Name] VARCHAR(50) NULL, 
    [Username] VARCHAR(50) NULL, 
    [Password] VARCHAR(50) NULL
)
